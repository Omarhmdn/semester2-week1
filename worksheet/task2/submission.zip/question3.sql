-- For each department, calculate the number of enrolments in its courses.
-- Expected Columns:
-- DepartmentName, TotalEnrolments



SELECT DepartmentName, COUNT(Enrolment.StudentId) AS TotalEnrolments FROM Department JOIN Enrolment GROUP BY Department.DepartmentName;

